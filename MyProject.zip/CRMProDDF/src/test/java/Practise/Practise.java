package Practise;

import java.io.IOException;

import org.testng.annotations.Test;

public class Practise {
	
	
	
	@Test
public void Execute() throws IOException
{
		
WrittingExcel.WriteExcel("kauwa122", "hdjd55", "hshgs565", "855558", "shhsg55", "fjfjd55", "558sdde", "eafdesf5556");

}

}
